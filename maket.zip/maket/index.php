<?php
session_start();
$period_cookie = 2592000; // 30 днів (2592000 секунд)
 
if($_GET){
    setcookie("utm_source",$_GET['utm_source'],time()+$period_cookie);
    setcookie("utm_medium",$_GET['utm_medium'],time()+$period_cookie);
    setcookie("utm_term",$_GET['utm_term'],time()+$period_cookie);
    setcookie("utm_content",$_GET['utm_content'],time()+$period_cookie);
    setcookie("utm_campaign",$_GET['utm_campaign'],time()+$period_cookie);
}
 
if(!isset($_SESSION['utms'])) {
    $_SESSION['utms'] = array();
    $_SESSION['utms']['utm_source'] = '';
    $_SESSION['utms']['utm_medium'] = '';
    $_SESSION['utms']['utm_term'] = '';
    $_SESSION['utms']['utm_content'] = '';
    $_SESSION['utms']['utm_campaign'] = '';
}
$_SESSION['utms']['utm_source'] = $_GET['utm_source'] ? $_GET['utm_source'] : $_COOKIE['utm_source'];
$_SESSION['utms']['utm_medium'] = $_GET['utm_medium'] ? $_GET['utm_medium'] : $_COOKIE['utm_medium'];
$_SESSION['utms']['utm_term'] = $_GET['utm_term'] ? $_GET['utm_term'] : $_COOKIE['utm_term'];
$_SESSION['utms']['utm_content'] = $_GET['utm_content'] ? $_GET['utm_content'] : $_COOKIE['utm_content'];
$_SESSION['utms']['utm_campaign'] = $_GET['utm_campaign'] ? $_GET['utm_campaign'] : $_COOKIE['utm_campaign'];

$price = 199; // Ціна на сайтів
$product_id = 12; // ID товару CRM
$product_name = 'ПРЕС-ФОРМА ДЛЯ ПЕЛЬМЕНІВ'; // Назва товару
$currency = 'грн'; // валюта
$quantity = 1;


$fbq_code = "410946274942551";


?>

<!DOCTYPE html><html lang="uk"><head>
    <!-- Removed by WebCopy --><!--<base href="/site/pressformapelmenvar_ogomart_ua/">--><!-- Removed by WebCopy -->
        <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>
        Машинка для ліпки вареників та пельменів    </title>
    <meta name="description" content="Машинка для ліпки вареників та пельменів">
    <meta name="keywords" content="Машинка для ліпки вареників та пельменів">
    <link rel="icon" type="image/png" href="favicon.png">
    <link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <link href="css2" rel="stylesheet">
    <link href="css2-1" rel="stylesheet">
    <!--[if lt IE 9]>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script>
    <![endif]-->

<meta name="csrf-param" content="_csrf">
<meta name="csrf-token" content="A5JQpEvMwR_K8nBD4P9AZuUFLKKXntFJyy9ceP9PfTNg9jTDJaCgS4uEKSHT0m0RqWx17879pB7yAjcrvANKdg==">
<!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '<?php echo $fbq_code; ?>');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=<?php echo $fbq_code; ?>&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->
</head>
<body>
<script type="application/ld+json" id="mySchema">{"@context":"https://schema.org/","@type":"Offer","sku":2202,"name":"Пресс - форма для лепки вареников и пельменей 2 в 1","category":"Товары для Кухни","availability":"https://schema.org/InStock","price":199,"priceCurrency":"UAH"}</script>    <!--main_wrapper-->
    <div class="main_wrapper">
        <header class="active">
            
            
            <svg class="nav-button" id="hamburger" fill="none" viewBox="0 0 52 23">
                <path stroke="#fff" stroke-linecap="round" stroke-width="3" d="M2 1.5h48M2 21.5h48M2 11.5h48"></path></svg>
        </header>
        <nav id="menu" class="modal-body">
            <div class="modal-block">
                <ul>
                    <li>
                        <a href="index.htm#home">Головна </a><svg viewBox="0 0 16 16">
                            <path d="M6 8l4-3.5v7L6 8z"></path></svg>
                    </li>
                    <li>
                        <a href="index.htm#video">Відео </a><svg viewBox="0 0 16 16">
                            <path d="M6 8l4-3.5v7L6 8z"></path></svg>
                    </li>
                    <li>
                        <a href="index.htm#peculiarities">ПЕРЕВАГИ </a><svg viewBox="0 0 16 16">
                            <path d="M6 8l4-3.5v7L6 8z"></path></svg>
                    </li>
                    <li>
                        <a href="index.htm#description">Опис </a><svg viewBox="0 0 16 16">
                            <path d="M6 8l4-3.5v7L6 8z"></path></svg>
                    </li>
                    <li>
                        <a href="index.htm#characteristic">ХАРАКТЕРИСТИКИ </a><svg viewBox="0 0 16 16">
                            <path d="M6 8l4-3.5v7L6 8z"></path></svg>
                    </li>
                    <li>
                        <a href="index.htm#feedback">ВІДГУКИ </a><svg viewBox="0 0 16 16">
                            <path d="M6 8l4-3.5v7L6 8z"></path></svg>
                    </li>
                    <li>
                        <a href="#order_form">замовити </a><svg viewBox="0 0 16 16">
                            <path d="M6 8l4-3.5v7L6 8z"></path></svg>
                    </li>
                </ul>
            </div>
        </nav>
        <!-- header 3 -->
        <div id="home" class="offer_section offer3 offer_section-top" style=" margin: 0; ">
            <div class="benefits_list clearfix">
                <div class="benefit_item">Доставка по Україні</div>
                <div class="benefit_item">Обмежена пропозиція</div>
                <div class="benefit_item">Оплата при отриманні</div>
            </div>
            <div class="image_block">
                <h1 class="box-title"><div class="text">Прес-форма <span> для пельменів і вареників 2 в 1 </span></div></h1>
                <img class="offer_image" src="images/offer__image.jpg" alt="Прес-форма для пельменів і вареників 2 в 1" title="Прес-форма для пельменів і вареників 2 в 1">
                <div class="discount_block">
                    <div class="value">-35%</div>
                    <div class="text">знижка</div>
                </div>
            </div>
            <div class="timer_block clearfix">
                <p>Ця пропозиція закінчиться через:</p>
                <div class="timer clearfix">
                    <div class="timer_item">
                        <div class="text">годин</div>
                        <div class="count hours"></div>
                    </div>
                    <div class="timer_item">
                        <div class="text">хвилин</div>
                        <div class="count minutes"></div>
                    </div>
                    <div class="timer_item">
                        <div class="text">секунд</div>
                        <div class="count seconds"></div>
                    </div>
                </div>
            </div><div class="price_block">
                <div class="price_item old">
                    <div class="text">
                        Звичайна ціна:
                    </div>
                    <div class="value">
                        <span>332</span>
                        <small>грн.</small>
                    </div>
                </div>
                <div class="price_item new">
                    <div class="text">
                        Ціна по акції:
                    </div>
                    <div class="value">
                        <span>199</span>
                        <small>грн.</small>
                    </div>
                </div>
            </div>
            <ul id="peculiarities">
                <li>Прес для тіста та форма для ліплення 2 в 1</li>
                <li>Надійна конструкція</li>
                <li>Стильний дизайн впишеться в будь-який інтер'єр</li>
                <li>Ідеальний край пельменів або вареників</li>
                <li>Легке та швидке приготування</li>
            </ul>
            <div class="btn-block">
                <a href="#order_form" class="button">Придбати зараз</a>
            </div>
            <div class="products_count">* Купили <b>17</b> шт за акцією</div>
        </div>
        <!-- /header 3 -->
        <!-- /header 3 -->
        <!-- video -->
        <div id="video" class="video_block">
            <div class="youtube" id="uA-Y4uF_1HI"><img src="images/bg-preview.jpg" alt="Прес-форма для пельменів і вареників 2 в 1" title="Прес-форма для пельменів і вареників 2 в 1"></div>
        </div>
        <!-- /video -->
        <!--description_section-->
        <section id="description" class="description_section">
            <h2 class="title">
                Прес-форма <span> для пельменів і вареників 2 в 1 </span>
            </h2>
            <div class="text_block">
                <p>Прес форма для пельменів і вареників 2 в 1 - Поєднує в собі прес для тіста і формочку для пельменів і вареників. </p>
            </div>
            <div class="image_block">
                <img src="images/01.jpg" alt="Прес-форма для пельменів і вареників 2 в 1" title="Прес-форма для пельменів і вареників 2 в 1">
            </div>
            <div class="text_block">
                <p>Готуйте вареники, міні-чебуреки та інші вироби з тіста за допомогою зручної форми для вареників.</p>
                <p>Форма проста в застосуванні, економить сили та час. Вам не потрібно ніяких особливих навичок, щоб приготувати смачну їжу.</p>
            </div>
            <div class="image_block">
                <img src="images/02.jpg" alt="Прес-форма для пельменів і вареників 2 в 1" title="Прес-форма для пельменів і вареників 2 в 1">
            </div>
            <div class="text_block">
                <p>Якісна форма для ліплення вареників і пельменів, виконана з харчового пластику, абсолютно безпечна для продуктів.</p>
            </div>
            <div class="image_block">
                <img src="images/03.jpg" alt="Прес-форма для пельменів і вареників 2 в 1" title="Прес-форма для пельменів і вареників 2 в 1">
            </div>
            <div class="text_block">
                <p>Для цієї форми не потрібні ідеально рівні краї у тіста, форма сама обрізає край під час закриття сторін. Таким чином, легко впорається з ліпленням не тільки дорослий, а й діти.
                </p>
            </div>
            <div class="image_block">
                <img src="images/04.jpg" alt="Прес-форма для пельменів і вареників 2 в 1" title="Прес-форма для пельменів і вареників 2 в 1">
            </div>
            <div class="text_block">
                <p>Пельменниця заощадить ваш час і сили. Ліпити вареники з нею одне задоволення!
                </p>
            </div>
            <div class="btn-block">
                <a href="#order_form" class="button">Придбати зараз</a>
            </div>
            <div class="products_count">* Купили <b>17</b> шт за акцією</div>
            <br>
            <div class="image_block">
                <img src="images/000.jpg" alt="Прес-форма для пельменів і вареників 2 в 1" title="Прес-форма для пельменів і вареників 2 в 1">
            </div>
        </section>
        <!--/description_section-->
        <h2 id="characteristic" class="title">Характеристики</h2>
        <!--characteristics_list2-->
        <div class="characteristics_list2">
            <div class="characteristic_item">
                <div class="text">Розміри - 28,5 Х 6,3 Х 12 см</div>
            </div>
            <div class="characteristic_item">
                <div class="text">Вага - 200 г</div>
            </div>
            <div class="characteristic_item">
                <div class="text">Матеріал - Харчовий пластик</div>
            </div>
        </div>
        <h2 id="characteristic" class="title">Комплектація</h2>
        <!--characteristics_list2-->
        <div class="characteristics_list2">
            <div class="characteristic_item">
                <div class="text">Прес форма - 1 шт</div>
            </div>
            <div class="characteristic_item">
                <div class="text">Упаковка</div>
            </div>
        </div>
        <div class="image_block">
            <img src="images/111.jpg" alt="Прес-форма для пельменів і вареників 2 в 1" title="Прес-форма для пельменів і вареників 2 в 1">
        </div>
        <!--/characteristics_list2-->
        <!-- reviews 2 -->
        <section id="feedback" class="reviews2_section">
            <h2 class="title">Відгуки покупців</h2>
            <div class="reviews_stats_block">
                <p><b>98%</b> покупців рекомендують цей товар</p>
                <div class="line"></div>
            </div>
            <div class="reviews_list1 owl-carousel">
                <div class="review_item">
                    <img class="photo" src="images/rev1.jpg" alt="Прес-форма для пельменів і вареників 2 в 1" title="Прес-форма для пельменів і вареників 2 в 1">
                </div>
                <div class="review_item">
                    <img class="photo" src="images/rev2.jpg" alt="Прес-форма для пельменів і вареників 2 в 1" title="Прес-форма для пельменів і вареників 2 в 1">
                </div>
            </div>
        </section>
        <!-- /reviews 2 -->
        <!-- order steps 2 -->
        <div class="order_steps_list1 clearfix">
            <h2 class="title">Як замовити?</h2>
            <div class="box">
                <div class="step_item">
                    <div class="number">1</div>
                    <h4>Заявка</h4>
                    <p>Залишаєте заявку на нашому сайті</p>
                </div>
                <div class="step_item">
                    <div class="number">2</div>
                    <h4>Дзвінок</h4>
                    <p>Менеджер передзвонить для уточнення деталей</p>
                </div>
                <div class="step_item">
                    <div class="number">3</div>
                    <h4>Надсилання</h4>
                    <p>Доставляємо ваш товар протягом
                        1-3
                        днів</p>
                </div>
                <div class="step_item">
                    <div class="number">4</div>
                    <h4>Отримання</h4>
                    <p>Оплачуєте при отриманні на пошті</p>
                </div>
            </div>
        </div>
        <!-- result.php? steps 2 -->
        <!-- order 3 -->
        <section class="offer_section offer3">
            <div class="title_block">
            </div>
            <div class="timer_block clearfix">
                <p>Ця пропозиція закінчиться через:</p>
                <div class="timer clearfix">
                    <div class="timer_item">
                        <div class="text">годин</div>
                        <div class="count hours"></div>
                    </div>
                    <div class="timer_item">
                        <div class="text">хвилин</div>
                        <div class="count minutes"></div>
                    </div>
                    <div class="timer_item">
                        <div class="text">секунд</div>
                        <div class="count seconds"></div>
                    </div>
                </div>
            </div>
            <div class="image_block">
                <h1 class="box-title"><div class="text">Прес-форма <span> для пельменів і вареників 2 в 1 </span></div></h1>
                <img class="offer_image" src="images/offer__image.jpg" alt="Прес-форма для пельменів і вареників 2 в 1" title="Прес-форма для пельменів і вареників 2 в 1">
                <div class="discount_block">
                    <div class="value">-35%</div>
                    <div class="text">знижка</div>
                </div>
            </div>
            <div class="benefits_list clearfix">
                <div class="benefit_item">Доставка по Україні</div>
                <div class="benefit_item">Обмежена пропозиція</div>
                <div class="benefit_item">Оплата при отриманні</div>
            </div>
            <div class="price_block">
                <div class="price_item old">
                    <div class="text">
                        Звичайна ціна:
                    </div>
                    <div class="value">
                        <span>332</span>
                        <small>грн.</small>
                    </div>
                </div>
                <div class="price_item new">
                    <div class="text">
                        Ціна по акції:
                    </div>
                    <div class="value">
                        <span>199</span>
                        <small>грн.</small>
                    </div>
                </div>
            </div>
            <ul>
                <li>Прес для тіста та форма для ліплення 2 в 1</li>
                <li>Надійна конструкція</li>
                <li>Стильний дизайн впишеться в будь-який інтер'єр</li>
                <li>Ідеальний край пельменів або вареників</li>
                <li>Легке та швидке приготування</li>
            </ul>

            <h2>Залишіть заявку</h2>
            <form id="order_form" class="order_form" action="zakaz.php" method="post">
                <input type="hidden" name="s1" class="price_field_s1" value="<?php echo $price ?>"/>
                <input type="hidden" name="s2" class="price_field_s2" value="<?= $product_id ?>"/>
                <input type="hidden" name="s3" class="price_field_s3" value="<?= $product_name?>"/>
                <input type="hidden" name="s4" class="price_field_s4" value="<?= $quantity?>"/>
                <input type="hidden" name="s5" class="price_field_s5" value="<?= $fbq_code?>"/>
                <div class="btn-block">
                    <input class="field" type="text" name="name" placeholder="Введіть ваше ім'я" required />
                </div>
                <div class="btn-block">
                    <input class="field" type="tel" name="phone" id="phone" minlength="8" maxlength="15" placeholder="Введіть Ваш телефон" required />
                </div>
                <div class="btn-block">
                    <button class="button" type="submit">Придбати зараз</button>
                </div>
                <input type="hidden" name="_csrf" value="A5JQpEvMwR_K8nBD4P9AZuUFLKKXntFJyy9ceP9PfTNg9jTDJaCgS4uEKSHT0m0RqWx17879pB7yAjcrvANKdg==">
            </form>
            <div class="products_count">* Купили <b>17</b> шт за акцією</div>
        </section>
        <!-- result.php? 3 -->
        <!-- footer -->
        <footer class="footer_section">
            <div style="font-size:13px;text-align: center;">
              <p>
                                <br>
                Одеса, вул. М. Коцюбинського, 40              </p>
              <p style="text-align: center">

                Графік работи:
                Пн - Нд: 08:00 - 23:00 <br>                            
                <br>
                <a style="color:inherit;" href="policy.html">Політика конфіденційності</a>
                <br>
                <a style="color:inherit;" href="oferta.html">Публічна оферта</a>
                <br>
                <a style="color:inherit;" href="cookie.html">Файли cookie</a>
              </p>
            </div>
        </footer>
        <!-- /footer -->
    </div>
    <!--/main_wrapper-->
    <!-- scripts -->
    <script data-cfasync="false" src="js/email-decode.min.js"></script><script defer="" src="js/jquery.js" type="text/javascript"></script>
    <script defer="" src="js/previewYouTube.js"></script>
    <script defer="" src="js/owl.carousel.min.js"></script>
    <script defer="" src="js/scripts.js"></script>
    <!-- /scripts -->
<script src="js/jquery_1.js"></script>
<script>jQuery(function ($) {

            $('a[href^="/#"]').click(function(e){
                e.preventDefault();
                var _href = $(this).attr('href').slice(1);
                $('html, body').animate({scrollTop: $(_href).offset().top+'px'});
                return false;
            });
        
});</script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var isButtonBlocked = false;

            var forms = document.querySelectorAll('form');

            forms.forEach(function(form) {
                var submitButton = form.querySelector('.btn');

                form.addEventListener('submit', function(event) {
                    // Перевірка, чи кнопка не заблокована
                    if (!isButtonBlocked) {
                        // Блокуємо кнопку
                        isButtonBlocked = true;
                        submitButton.disabled = true;

                        // Затримка на 5 секунд
                        setTimeout(function() {
                            // Розблокуємо кнопку після затримки
                            isButtonBlocked = false;
                            submitButton.disabled = false;
                        }, 10000);
                    } else {
                        // Якщо кнопка вже заблокована, відміна відправки форми
                        event.preventDefault();
                    }
                });
            });
        });
    </script>


</body></html>