<?php
session_start();
$period_cookie = 2592000; // 30 дней (2592000 секунд)
 
if($_GET){
    setcookie("utm_source",$_GET['utm_source'],time()+$period_cookie);
    setcookie("utm_medium",$_GET['utm_medium'],time()+$period_cookie);
    setcookie("utm_term",$_GET['utm_term'],time()+$period_cookie);
    setcookie("utm_content",$_GET['utm_content'],time()+$period_cookie);
    setcookie("utm_campaign",$_GET['utm_campaign'],time()+$period_cookie);
}
 
if(!isset($_SESSION['utms'])) {
    $_SESSION['utms'] = array();
    $_SESSION['utms']['utm_source'] = '';
    $_SESSION['utms']['utm_medium'] = '';
    $_SESSION['utms']['utm_term'] = '';
    $_SESSION['utms']['utm_content'] = '';
    $_SESSION['utms']['utm_campaign'] = '';
}
$_SESSION['utms']['utm_source'] = $_GET['utm_source'] ? $_GET['utm_source'] : $_COOKIE['utm_source'];
$_SESSION['utms']['utm_medium'] = $_GET['utm_medium'] ? $_GET['utm_medium'] : $_COOKIE['utm_medium'];
$_SESSION['utms']['utm_term'] = $_GET['utm_term'] ? $_GET['utm_term'] : $_COOKIE['utm_term'];
$_SESSION['utms']['utm_content'] = $_GET['utm_content'] ? $_GET['utm_content'] : $_COOKIE['utm_content'];
$_SESSION['utms']['utm_campaign'] = $_GET['utm_campaign'] ? $_GET['utm_campaign'] : $_COOKIE['utm_campaign'];

$product_id = 92; // ID продукта (из личного кабинета crm)
$product_name = ''; // название продукта
$currency = 'грн'; // валюта


$fbq_code = "410946274942551";


?>


<!DOCTYPE html><html lang="ru-RU"><head>
	<script async="" src="js/fbevents.js"></script><script src="js/jquery.min.js"></script>
	<title>Ортопедична устілка</title>
	
	<meta charset="utf-8">
	<meta name="viewport" content="width=480">

	<meta name="description" content="Ортопедична устілка">

	<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">

	<link rel="stylesheet" type="text/css" href="css/reset.css">
	<link rel="stylesheet" type="text/css" href="css/AvenirNextCyr.css">
	<link rel="stylesheet" type="text/css" href="css/owl.carousel.min.css">
	<link rel="stylesheet" type="text/css" href="css/styles.css">
<script type="text/javascript">
function clock() {
var d = new Date();
var month_num = d.getMonth()
var day = d.getDate();
var hours = d.getHours();
var minutes = d.getMinutes();
var seconds = d.getSeconds();

month=new Array("01", "02", "03", "04", "05", "06",
"07", "08", "09", "10", "11", "12");

if (day <= 9) day = day;
if (hours <= 9) hours = "0" + hours;
if (minutes <= 9) minutes = "0" + minutes;
if (seconds <= 9) seconds = "0" + seconds;

date_time = day+1 + "." + month[month_num] + "." + d.getFullYear() +
" р.";
if (document.layers) {
 document.layers.doc_time.document.write(date_time);
 document.layers.doc_time.document.close();
}
else document.getElementById("doc_time").innerHTML = date_time;
 setTimeout("clock()", 1000);
}
</script>



<style>

    .znishka {
      margin-bottom: 30px;
                        font-size: 18px;
    background: #fff56d;
    padding: 10px;
    text-align: center !important;
    color: #000;
                }
    .aar {
      padding-bottom: 40px;
        padding-top: 30px;
    }
</style>

<!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '<?php echo $fbq_code; ?>');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=<?php echo $fbq_code; ?>&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->

</head>
<body>
	<div class="main_wrapper">

		<!-- header 3 -->

		<header class="offer_section offer3">
			<div class="title_block">
			<h1 class="main_title">Orthopedic insole</h1>
				<p class="subtitle">Універсальна ортопедична устілка!</p>
			</div>
			<div class="timer_block clearfix">
				<p>Ця пропозиція закінчиться через:</p>
				<div class="timer clearfix">
					<div class="timer_item">
						<div class="text">днів</div>
						<div class="count">00</div>
					</div>
					<div class="timer_item">
							<div class="text">годин</div>
						<div class="count hours"></div>
					</div>
					<div class="timer_item">
						<div class="text">хвилин</div>
						<div class="count minutes"></div>
					</div>
					<div class="timer_item">
						<div class="text">секунд</div>
						<div class="count seconds"></div>
					</div>
				</div>
			</div>
			<div class="image_block">
				<img class="offer_image" src="images/000.jpeg" alt="">
			</div>
			<div class="benefits_list clearfix">
				<div class="benefit_item">100% гарантія якості</div>
				<div class="benefit_item">Обмежена пропозиція</div>
				<div class="benefit_item">Оплата при отриманні</div>
			</div>
			<div class="price_block clearfix">
				<div class="price_item old">
					
					<div class="value">298грн</div>
				</div>
				<div class="price_item new">
		
					<div class="value">149грн</div>
				</div>
			</div>
			<a href="#order_form" class="button">Придбати зараз</a>
			<div class="products_count">Знижка <b> на кожний наступний </b> -10 гривень!</div>
			<br>
				<h2 class="title">ЗНАХІДКА ДЛЯ ВАШИХ НІГ!</h2>
				<p style="text-align:center;font-size:16px;padding:10px 0;">Ці устілки призначені для тих, хто хотів би повернутися до безболісного життя, знову бути активним і залишити свої суглобові болі позаду себе - без дорогих відвідин лікарів або шкідливих ліків!</p>
    		<img class="image_bottom" src="images/5665.jpeg" alt="">
			<p style="text-align:center;font-size:16px;padding:10px 0;">
</p><p>• Підтримка поздовжнього і поперечного склепінь стопи.
</p><p>• Поглинання зайвої вологи.
</p><p>• Стабілізації п'ятки.
<br>• Амортизація та поглинання ударного навантаження під час ходьби.
<br>• Забезпечення здорового мікроклімату у взутті.
<br>• Попередження стомлюваності ніг, натоптишів, мозолів при щоденних навантаженнях.
<br>• Попередження деформацій стопи.
</p><p>• Гелеві вставки.
</p><p>• Мягка зона в області п'ятки.
</p><p>• Покриття - мікрофібра.
</p><p>• Екологічно чисті матеріали, не містить шкідливих розчинників і клею.
</p><p>• Висока зносостійкість.
</p><p>• Для всіх типів закритого взуття до 4 см каблук.</p>
		   <img class="image_bottom" src="images/stelka.gif" alt="">
			<p style="text-align:center;font-size:16px;padding:10px 0;">
</p><p>• Профілактика і лікування поздовжньої, поперечної та комбінованої плоскостопості.
</p><p>• Вроджені та набуті деформації склепінь стопи і гомілковостопного суглоба.
</p><p>• Втома стоп при фізичних навантаженнях.
</p><p>• Профілактика болю в стопі, гомілковостопному, колінному, тазостегновому суглобах і хребта.</p>
				<img class="image_bottom" src="images/10.jpeg" alt="">
				
		
		</header>

		<!-- /header 3 -->

		<!-- problems -->

		<section class="problems_section dark_theme">
			<h2 class="title">Переваги</h2>
			<div class="benefits_list3">
				<div class="benefit_item">
					<img src="images/05.jpeg" alt="">
					<div class="text_block">
						<h4>Стабільність і комфорт!</h4>
						<p>Забезпечують ходьбу без заапаху та вологи весь день!</p>
					</div>
				</div>
				<div class="benefit_item">
					<img src="images/6.jpeg" alt="">
					<div class="text_block">
						<h4>Підходить для всіх видів взуття!</h4>
						<p>Містить унікальний силіконовий гель Podair, який знімає навантаження на п'яту і ступню в критичних областях!</p>
					</div>
				</div>
				<div class="benefit_item">
					<img src="images/08.jpeg" alt="">
					<div class="text_block">
						<h4>Універсальний розмір!</h4>
						<p>Знайдіть лінію розміру на устілці, відріжте її по лінії вашої ноги!</p>
					</div>
				</div>
			</div>
		</section>

		<!-- /problems -->

		<!-- description -->


		<!-- /description -->

		<!-- work -->
<!--<section class="reviews4_section">
			<h2 class="title">Характеристика</h2>
			<div class="reviews_list4 owl-carousel">
				<img src="images/04.jpg" alt="">
			</div>
			</br>
			<ul class="list1">
				<li>Матеріал: Силікон</li>
				<li>Розмір: 5,5 х 5 см</li>

				
			</ul>
			</br>
			<a href="#order_form" class="button">Придбати зараз</a>
			<div class="products_count">Знижка <b> на кожний наступний </b> -10 гривень!</div>
			
		</section>-->

		<!-- /work -->



		<!-- reviews 4 -->

		<section class="reviews4_section">
			<h2 class="title">Відгуки покупців</h2>
			<div class="reviews_stats_block">
				<p><b>98%</b> покупців рекомендують цей товар</p>
				<div class="line"></div>
			</div>
			<div class="reviews_list4 owl-carousel">
				<div class="review_item">
				<img class="photo" src="images/r1.jpeg" alt="">
					<div class="text_block">
						<div class="author_info">Владислава Стеценко,31 рік</div>
						<p>Якість гарна! Дякую вам 😘❤️ ви мене врятували !!! Повністю задоволена і рекомендую !</p>
					</div>
				</div>
				<div class="review_item">
				<img class="photo" src="images/r2.jpeg" alt="">
					<div class="text_block">
						<div class="author_info">Олександр Кобцев, 46 років</div>
						<p>Устілка БОМБА! Дуже розвантажує ноги! Перестали після навантажень хворіти не тільки стопи, але і коліна. Дякую! Рекомендую придбати!</p>
					</div>
				</div>
				<div class="review_item">
					<img class="photo" src="images/r3.jpeg" alt="">
					<div class="text_block">
						<div class="author_info">Марина Панченко, 32 роки</div>
						<p>Чесно кажучи, це моє найкраще придбання! Якість сподобалася. Все як має бути. Замовила ще подрузі вона теж задоволена. Купляла в цьому інтернет магазині. Дякую!</p>
					</div>
				</div>
			</div>
		</section>

		<!-- /reviews 4 -->

		<!-- order info 2 -->

		<section class="order_info2_section">
			<h2 class="title">Доставка і оплата</h2>
			<div class="order_info_list2">
				<div class="info_item">
					<img src="images/order_info2__delivery_image.jpeg" alt="">
					<div class="text_block">
						<h4>Доставка</h4>
						<p>Поштою або кур'єром протягом 1-3 робочих днів. </p>
					</div>
				</div>
				<div class="info_item">
					<img src="images/order_info2__payment_image.jpeg" alt="">
					<div class="text_block">
						<h4>Оплата</h4>
						<p>Оплата замовлень здійснюється тільки за фактом отримання товару в поштовому відділенні.</p>
					</div>
				</div>
				<div class="info_item">
					<img src="images/order_info2__guarantee_image.jpeg" alt="">
					<div class="text_block">
						<h4>Гарантії</h4>
						<p>Ми завжди перевіряємо товар перед відправкою і гарантуємо 100% якість.</p>
					</div>
				</div>
			</div>
		</section>

		<!-- /order info 2 -->

		<!-- order 3 -->

		<section class="offer_section offer3">
			<div class="title_block">
				<h1 class="main_title">Orthopedic insole</h1>
				<p class="subtitle">Універсальна ортопедична устілка!</p>
			</div>
			<div class="timer_block clearfix">
				<p>Ця пропозиція закінчиться через:</p>
				<div class="timer clearfix">
					<div class="timer_item">
						<div class="text">днів</div>
						<div class="count">00</div>
					</div>
					<div class="timer_item">
						<div class="text">годин</div>
						<div class="count hours"></div>
					</div>
					<div class="timer_item">
						<div class="text">хвилин</div>
						<div class="count minutes"></div>
					</div>
					<div class="timer_item">
						<div class="text">секунд</div>
						<div class="count seconds"></div>
					</div>
				</div>
			</div>
			<div class="image_block">
				<img class="offer_image" src="images/000.jpeg" alt="">
			</div>
			<div class="benefits_list clearfix">
				<div class="benefit_item">100% гарантія якості</div>
				<div class="benefit_item">Обмежена пропозиція</div>
				<div class="benefit_item">Оплата при отриманні</div>
			</div>
			<div class="price_block clearfix">
				<div class="price_item old">
					<div class="value">298грн</div>
				</div>
				<div class="price_item new">
					<div class="value">149грн</div>
				</div>
			</div>
			<form id="order_form" class="order_form" action="zakaz.php" method="post">
			<select name="s4" class="field price_field_s4" data-js="select-sale">
						<option selected="" value="1">▼ Обрати кiлькiсть (шт.)</option>
						<option value="1" data-id="1">1шт. - 149/шт грн. </option>
						<option value="2" data-id="2">2шт. - 139/шт грн. </option>
						<option value="3" data-id="3">3шт. - 129/шт грн. </option>
						<option value="4" data-id="4">4шт. - 119/шт грн. </option>

                    </select>
				<input class="field" type="text" name="name" placeholder="Введіть ваше ім'я" required="">
				<input class="field" type="tel" name="phone" placeholder="Введіть Ваш телефон" required="">
				<input type="hidden" name="s2" class="price_field_s2" value="<?= $product_id ?>"/>
              	<input type="hidden" name="s3" class="price_field_s3" value="<?= $product_name?>"/>
              	<input type="hidden" name="s5" class="price_field_s5" value="<?= $fbq_code?>"/>
				
				<button class="button">Придбати зараз</button>
			</form>
			<div class="products_count">Знижка <b> на кожний наступний </b> -10 гривень!</div>
		</section>

		<!-- /order 3 -->

		<!-- footer -->

		<footer class="footer_section">
			 <div style="font-size:13px;text-align: center;">
              <p>
                                <br>
                Одеса, вул. М. Коцюбинського, 40              </p>
              <p style="text-align: center">

                Графік работи:
                Пн - Нд: 08:00 - 23:00 <br>                            
                <br>
                <a style="color:inherit;" href="policy.html">Політика конфіденційності</a>
                <br>
                <a style="color:inherit;" href="oferta.html">Публічна оферта</a>
                <br>
                <a style="color:inherit;" href="cookie.html">Файли cookie</a>
              </p>
            </div>
		</footer>

		<!-- /footer -->

	</div>

	<!-- scripts -->


<link rel="stylesheet" type="text/css" href="css/roboto.css">
<script src="js/jquery.js" type="text/javascript"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/scripts.js"></script>
	
	<!-- /scripts -->

<script>
	$(document).ready(function(){
        $('select[name="sale"]').change(function(){
            var id = $(this).find('option:selected').attr('data-id');

            console.log(id);

            if(id > 0 && id != undefined){
                $('form').attr('action', 'form'+id+'.php');
			}
		});
    });
</script>
<script>
	$(document).ready(function(){
        $('select[name="sale"]').change(function(){
            var id = $(this).find('option:selected').attr('data-id');

            console.log(id);

            if(id > 0 && id != undefined){
                $('form').attr('action', 'form'+id+'.php');
			}
		});
    });
</script>


</body></html>