
<?php
session_start();
 
// формируем массив с товарами в заказе (если товар один - оставляйте только первый элемент массива)
   $products_list[] = array(
            'product_id' => $_REQUEST['product_id'],    //код товара (из каталога CRM)
            'price'      => $_REQUEST['product_price'], //цена товара 1
            'count' => $_REQUEST['quantity'],                      //количество товара
);
$products = urlencode(serialize($products_list));
$sender = urlencode(serialize($_SERVER));

// Отримуємо ціну товару з запиту
$quantity = $_REQUEST['quantity'];

// Встановлюємо значення 'comment' залежно від ціни товару
if ($quantity == 1) {
    $comment = '1 шт';
} elseif ($quantity == 2) {
    $comment = '2 шт';
} elseif ($quantity == 3) {
    $comment = '3 шт';
} elseif ($quantity == 4) {
    $comment = '4 шт';
} else {
    $comment = 'Не вдалося отримати кількість'; // за замовчуванням
}

// параметры запроса
$data = array(
    'key'             => $_REQUEST['crm_key'], //Ваш секретный токен
    'order_id'        => number_format(round(microtime(true)*10),0,'.',''), //идентификатор (код) заказа (*автоматически*)
    'country'         => 'UA',                         // Географическое направление заказа
    'office'          => '1',                          // Офис (id в CRM)
    'products'        => $products,                    // массив с товарами в заказе
    'bayer_name'      => $_REQUEST['name'],            // покупатель (Ф.И.О)
    'phone'           => $_REQUEST['phone'],           // телефон
    'email'           => $_REQUEST['email'],           // электронка
    'comment'         => $comment,    // комментарий
    'delivery'        => $_REQUEST['delivery'],        // способ доставки (id в CRM)
    'delivery_adress' => $_REQUEST['delivery_adress'], // адрес доставки
    'payment'         => '',                           // вариант оплаты (id в CRM)
    'sender'          => $sender,                        
    'utm_source'      => $_SESSION['utms']['utm_source'],  // utm_source
    'utm_medium'      => $_SESSION['utms']['utm_medium'],  // utm_medium
    'utm_term'        => $_SESSION['utms']['utm_term'],    // utm_term
    'utm_content'     => $_SESSION['utms']['utm_content'], // utm_content
    'utm_campaign'    => $_SESSION['utms']['utm_campaign'],// utm_campaign
    'additional_1'    => 'A',                               // Дополнительное поле 1
    'additional_2'    => '',                               // Дополнительное поле 2
    'additional_3'    => '',                               // Дополнительное поле 3
    'additional_4'    => ''                                // Дополнительное поле 4
);
 
// запрос
// запрос
$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, 'http://' . $_REQUEST['crm_url'] . '/api/addNewOrder.html');
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

$namerep = $_GET['namerep'];
$phonerep = $_GET['phonerep'];

$out = curl_exec($curl);



curl_close($curl);

//$out – ответ сервера в формате JSON
?>

<!DOCTYPE html>

<html lang="ua_UK">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
            <title>Дякуємо за замовлення</title>
        
    <meta http-equiv="Cache-Control" content="max-age=3600, must-revalidate">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="thankyou.css" rel="stylesheet">
    <link rel="stylesheet" href="stylephpform.css">

<!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '<?php echo $fbq_code; ?>');
fbq('track', 'Lead');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=<?php echo $fbq_code; ?>&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->
</head>

<body class="man">


    <div class="section block-1">
        <div class="wrap">
            <div class="top-title">
                <h2>
                    Дякуємо за замовлення!
                </h2>

                <div class="client-details">
                                            <div class="client-details-item">
                            <b>Імʼя:</b> <span><?php echo $namerep; ?></span>
                        </div>
                    
                    <div class="client-details-item">
                        <b>Телефон:</b> <span><?php echo $phonerep; ?></span>
                    </div>
                </div>
                <div>
                    Оператор зв`яжеться з Вами найближчим часом.
                </div>
                <div class="line"><img src="order_page_files/thankyou-divider.png" alt=""></div>
                <div class="text">
                    <p>
                        Якщо Ви допустили помилку, поверніться на сторінку замовлення та відправте форму повторно.
                    </p>
                    <a class="return-to-site" href="/">Повернутися</a>
                </div>
            </div>
        </div>
    </div>
   


<div class="overlay" style="display:none;"></div>
<script src="order_page_files/jquery.js"></script>
<script src="order_page_files/sweetalert2.js">
</script>
<script>
    let popUpBtns = document.querySelectorAll('.btn-popup.dop')
    if (popUpBtns.length !== 0) {
        document.querySelectorAll('.btn-popup.dop').forEach(function (button) {
            button.addEventListener('click', function (e) {
                e.preventDefault();
                document.querySelector('.popup').style.display = 'block';
                document.querySelector('.overlay').style.cssText =
                    'display: block;width: 100%;height: 100%;position: fixed;top: 0;left: 0;right: 0;bottom: 0;background: rgba(0, 0, 0, .7);z-index:3;';
            });
        });
        document.querySelector('.close').addEventListener('click', function () {
            document.querySelector('.popup').style.display = 'none';
            document.querySelector('.overlay').style.display = 'none';
        });
    }
</script>

</body>

</html>