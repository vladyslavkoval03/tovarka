<?php

$name = stripslashes(htmlspecialchars($_POST['name']));
$namerep = stripslashes(htmlspecialchars($_POST['name']));
$phone = stripslashes(htmlspecialchars($_POST['phone']));
$phonerep = stripslashes(htmlspecialchars($_POST['phone']));
$date = date('Y-m-d H:i:s');
$ip_address = $_SERVER['REMOTE_ADDR'];

$country = 'UA';

$product_id = stripslashes(htmlspecialchars($_POST['s2']));
$product_name = stripslashes(htmlspecialchars($_POST['s3']));
$quantity = stripslashes(htmlspecialchars($_POST['s4']));
$fbq_code = stripslashes(htmlspecialchars($_POST['s5']));

if ($quantity == 15) {
    $product_price = 249;
} elseif ($quantity == 30) {
    $product_price = 399;  
} elseif ($quantity == 45) {
    $product_price = 499; 
} elseif ($quantity == 60) {
    $product_price = 599; 
} else {
    $product_price = 699;
}

$total = $product_price * 1;


if (stripslashes(htmlspecialchars($_POST['country']))) {
    $country = stripslashes(htmlspecialchars($_POST['country']));
}

$crm_key = '25c30f2157ab81b35a2db82069fe7051';
$crm_url = 'bluehive.lp-crm.biz';


// Встановлюємо токен вашого бота
$botToken = '7120732178:AAFNBRubbf_l_9jOVZ5K7VOwd6e-KSQ9d7s';
$chatId = '576363413';

// Підготовка тексту повідомлення
$text = "Нове замовлення:\n\nІм'я: $name\nТелефон: $phone\nID продукта: $product_id\nТовар: $product_name\nЦіна: $product_price\nРозмір: $quantity м\nСумма: $total\nДата: $date\nIP-замовлення: $ip_address";

// Відправка повідомлення за допомогою API Telegram
$response = file_get_contents("https://api.telegram.org/bot$botToken/sendMessage?chat_id=$chatId&text=" . urlencode($text));

$subject = 'Заказ товара - ' . $product_name;
$addressat = "test222@gmail.com";

$success_url = "/form-ok.php?name=$name&phone=$phone&country=$country&product_price=$product_price&product_id=$product_id&product_name=$product_name&email=$email&namerep=$namerep&phonerep=$phonerep&quantity=$quantity&fbq_code=$fbq_code&crm_key=$crm_key&crm_url=$crm_url";
$message = "ФИО: {$name}\nКонтактный телефон: {$phone}";


$sendMail = mail($addressat, $subject, $message, "Content-type:text/plain;charset=utf-8\r\n");
if($sendMail){
    header('Location: ' . $success_url);
} else {
    echo '<h1 style="color:green;">Ошибка!</h1>';
}


exit;