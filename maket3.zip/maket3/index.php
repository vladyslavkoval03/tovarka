<?php
session_start();
$period_cookie = 2592000; // 30 дней (2592000 секунд)
 
if($_GET){
    setcookie("utm_source",$_GET['utm_source'],time()+$period_cookie);
    setcookie("utm_medium",$_GET['utm_medium'],time()+$period_cookie);
    setcookie("utm_term",$_GET['utm_term'],time()+$period_cookie);
    setcookie("utm_content",$_GET['utm_content'],time()+$period_cookie);
    setcookie("utm_campaign",$_GET['utm_campaign'],time()+$period_cookie);
}
 
if(!isset($_SESSION['utms'])) {
    $_SESSION['utms'] = array();
    $_SESSION['utms']['utm_source'] = '';
    $_SESSION['utms']['utm_medium'] = '';
    $_SESSION['utms']['utm_term'] = '';
    $_SESSION['utms']['utm_content'] = '';
    $_SESSION['utms']['utm_campaign'] = '';
}
$_SESSION['utms']['utm_source'] = $_GET['utm_source'] ? $_GET['utm_source'] : $_COOKIE['utm_source'];
$_SESSION['utms']['utm_medium'] = $_GET['utm_medium'] ? $_GET['utm_medium'] : $_COOKIE['utm_medium'];
$_SESSION['utms']['utm_term'] = $_GET['utm_term'] ? $_GET['utm_term'] : $_COOKIE['utm_term'];
$_SESSION['utms']['utm_content'] = $_GET['utm_content'] ? $_GET['utm_content'] : $_COOKIE['utm_content'];
$_SESSION['utms']['utm_campaign'] = $_GET['utm_campaign'] ? $_GET['utm_campaign'] : $_COOKIE['utm_campaign'];

$product_id = 0; // ID продукта (из личного кабинета crm)
$product_name = 'ШЛАНГ ДЛЯ ПОЛИВУ XHOSE'; // название продукта
$currency = 'грн'; // валюта


$fbq_code = "410946274942551";


?>


<!DOCTYPE html><html lang="uk"><head>

<script async="" src="js/fbevents.js"></script><script src="js/jquery.min_1.js"></script> 	<title>Шланг для поливу XHOSE - Найзручніший і найміцніший </title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=480">
	<meta name="description" content="Це єдиний шланг, який ніколи не загинається і не закручується. Полив квітів, миття машини або будь-яке інше заняття з xHosepro принесуть Вам задоволення!">
	<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
	<link rel="stylesheet" type="text/css" href="css/reset.css">
	<link rel="stylesheet" type="text/css" href="css/AvenirNextCyr.css">
	<link rel="stylesheet" type="text/css" href="css/owl.carousel.min.css">
	<link rel="stylesheet" type="text/css" href="css/styles.css">
<meta property="og:type" content="article">
<meta property="og:title" content="Шланг XHOSE">
<meta property="og:description" content="Xhosepro - останній винахід серед товарів для дому та саду. Унікальна конструкція інноваційного шланга дозволяє йому збільшуватися в довжину втричі під напором води і робить його неймовірно легким, компактним та зручним у використанні. ">
<meta property="og:url" content="">


<!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '<?php echo $fbq_code; ?>');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=<?php echo $fbq_code; ?>&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->


</head>
<body>
	<div class="main_wrapper">
		<!-- header 1 -->
		<header class="offer_section offer1">
			<section class="sect3 color_bg">
			<div class="title_block">
				<h1 class="main_title">Шланг для поливу XHOSE <br><span style="color:yellow;">З НАСАДКОЮ У ПОДАРУНОК! </span></h1>

			</div>
			</section>
					<div class="box">
				<img class="offer_image" src="images/offer.jpg" alt="">
			</div>
			<div class="price_block clearfix">
				<div class="price_item old">
					<div class="text">Звичайна ціна:</div>
					<div class="value">475 грн</div>
				</div>
				<div class="discount_block">
					<div class="text">знижка</div>
					<div class="value">-47%</div>
				</div>
				<div class="price_item new">
					<div class="text">Ціна сьогодні від:</div>
					<div class="value">249 грн</div>
				</div>
			</div>
			<div class="timer_block clearfix">
				<p>До кінця акції залишилося:</p>
				<div class="timer clearfix">
					<div class="timer_item">
						<div class="count hours"></div>
						<div class="text">годин</div>
					</div>
					<div class="timer_item">
						<div class="count minutes"></div>
						<div class="text">хвилин</div>
					</div>
					<div class="timer_item">
						<div class="count seconds"></div>
						<div class="text">секунд</div>
					</div>
				</div>
			</div>
			<div class="products_count">Залишилось <b>12</b> шлангів по акції</div><br>
			<a href="#order_form" class="button">Замовити зі знижкою</a>
			
		</header>
		<section class="gif_sect" style="margin-top: 70px">
			<h2 class="title">Шланг XHOSE <span>зручний та надійний</span></h2>
			<img src="images/2.gif" alt="">
		</section>
		<section class="sect2">
			
			<p>Xhose —РЦей незамінний у господарстві шланг, автоматично збільшується в 3 рази при подачі води та швидко стискається після закінчення поливу. Економить місце і дуже зручний. Збільшуватися ВТРИЧІ під тиском води і робить його неймовірно легким (30 м = 450 грамів), компактним та зручним у використанні.</p>
			     <h2 class="title" style="margin-top: 70px">НАСАДКА НА 7 РЕЖИМІВ  <span>ПОЛИВУ В ПОДАРУНОК!</span></h2>
			<img src="images/big1.png" alt="">
			<br>
			<br>
			<br>
			<p>Цей шланг радикально відрізняється від будь-яких шлангів, які Ви коли-небудь бачили! Увімкніть воду, і шланг XHOSE автоматично почне подовжуватися. Звільнення від вузлів та перекручування. Завдяки мінливій фізичній структурі повністю виключається ймовірність заплутування шланга
			</p>
		</section>
  
		<section class="sect3 color_bg">
			<h2 class="title">Основні <span>переваги XHOSE</span></h2>
			<div class="benefits_list1 image_rounded">
				<div class="benefit_item">
					<img src="images/benef1.jpg" alt="">
					<h4>Стійкий до ударів та навантажень</h4>
					<p>Завдяки ударостійким з'єднувачам з <br>АБС-пластику</p>
				</div>
				<div class="benefit_item">
					<img src="images/3.gif" alt="">
					<h4>Довговічний та зносостійкий</h4>
					<p>Завдяки двошаровому латексу та поліефірному полотну</p>
				</div>
				<div class="benefit_item">
					<img src="images/4.gif" alt="">
					<h4>Довжина збільшується <br> в 3 рази</h4>
					<p>Швидко розтягується під тиском води</p>
				</div>
				<div class="benefit_item">
					<img src="images/benef2.jpg" alt="">
					<h4>Легкий та надійний</h4>
					<p>Вага шланга не перевищуєР450Рг</p>
				</div>
			</div>
		</section>
		<section class="sect4">
			<h2 class="title">Шланг <br>розтягується <span>від 9,8м до 30м</span></h2>
		</section>
		<section class="sect5">
			<h2 class="title">Як можна використовувати шланг</h2>
			<div class="use_block clearfix">
				<img src="images/s5_img.jpg" alt="">
				<ul class="list5">
					<li>Для поливу городу та саду</li>
					<li>Для миття машини та <br>гаража</li>
					<li>Для миття вікон та фасадів</li>
				</ul>
			</div>
		</section>
<section class="sect2">
			<h2 class="title">Ціни на більшу довжину</h2>
<ul>
<li><div class="products_count">
<p><strong>15 метрів - <span style="color: #85c00c;">249 грн</span>;</strong></p>
<p><strong>30 метрів - <span style="color: #85c00c;">399 грн</span>;</strong></p>
<p><strong>45 метрів - <span style="color: #85c00c;">499 грн</span>;</strong></p>
<p><strong>60 метрів - <span style="color: #85c00c;">599 грн</span>;</strong></p>
<p><strong>75 метрів - <span style="color: #85c00c;">699 грн</span>;</strong></p>
</div> </li>
</ul>
</section>
		<section class="sect6 color_bg">
			<h2 class="title">Характеристики</h2>
			<div class="slider owl-carousel">
				<img src="images/slider__image1.jpg" alt="">
				<img src="images/slider__image2.jpg" alt="">
				<img src="images/slider__image3.jpg" alt="">
			</div>
			<div class="characteristics_list1">
				<div class="characteristic_item">
					<div class="text">Матеріал шланга:</div>
					<div class="value">ткане поліефірне полотно, латекс</div>
				</div>
				<div class="characteristic_item">
					<div class="text">Матеріал з'єднувачів:</div>
					<div class="value">АБС-пластик</div>
				</div>
				<div class="characteristic_item">
					<div class="text">Довжина:<br>(шланг 30 м)</div>
					<div class="value">Під тиском води 30 м <br>У стані спокою 9,8 м</div>
				</div>
<div class="characteristic_item">
					<div class="text">В наявності:</div>
					<div class="value">15м, 30м, 45м, 60м, 75мР</div>
				</div> 				<div class="characteristic_item">
					<div class="text">Колір:</div>
					<div class="value">блакитний</div>
				</div>
				<div class="characteristic_item">
					<div class="text">Вага:</div>
					<div class="value">450г</div>
				</div>
		</div>
		</section>
		
		<section class="reviews4_section">
			<h2 class="title">Відгуки покупців</h2>
			<div class="reviews_list4 owl-carousel">
				<div class="review_item">
					<img class="photo" src="images/reviews__review1_photo.jpg" alt="">
					<div class="text_block">
						<div class="author_info">Катерина Зубець</div>
						<p>Шланг незвичайний на вигляд. Дуже зручний, а насадка – просто диво. Мені його подарували на день народження. Я його одразу приєднала. Дуже зручно, без усяких хомутиків та вигадок. Поливала їм дітей у спеку) Зробила "дощ" і вони дуже раділи.</p>
					</div>
				</div>
				<div class="review_item">
					<img class="photo" src="images/reviews__review2_photo.jpg" alt="">
					<div class="text_block">
						<div class="author_info">Володимир Гавриленко</div>
						<p>Шланг чудовий! Легкий – це його головна перевага! Чи не перекручується і не переламується. Коли наповнюється водою – поводиться як жива істота! Дякую!</p>
					</div>
				</div>
				<div class="review_item">
					<img class="photo" src="images/reviews__review3_photo.jpg" alt="">
					<div class="text_block">
						<div class="author_info">Петро Мельник</div>
						<p>Дякуємо за шланг! Я дуже задоволений тим, що його придбав. Навіть не очікував, що він може змінюватися в розмірі, і настільки компактний. Колишній шланг займав у моїй коморі цілий кут, а цей лежить на полиці і майже не займає місця, легкий і компактний. Велике спасибі за шланг та зручність доставки!</p>
					</div>
				</div>
			</div>
		</section>
		<section class="order_info1_section">
			<h2 class="title">Доставка та гарантії</h2>
			<div class="order_info_list1">
				<div class="info_item clearfix">
					<div class="icon_block">
						<img src="images/order_info1_light__delivery_icon.png" alt="">
					</div>
					<div class="text_block">
						<h4>Доставка</h4>
						<p>Відправлення на день замовлення. Вартість доставки уточнюйте у оператора. </p>
					</div>
				</div>
				<div class="info_item clearfix">
					<div class="icon_block">
						<img src="images/order_info1_light__payment_icon.png" alt="">
					</div>
					<div class="text_block">
						<h4>Оплата</h4>
						<p>Оплата замовлень здійснюється за фактом отримання товару у поштовому відділенні</p>
					</div>
				</div>
				<div class="info_item clearfix">
					<div class="icon_block">
						<img src="images/order_info1_light__guarantee_icon.png" alt="">
					</div>
					<div class="text_block">
						<h4>Гарантії</h4>
						<p>Ми завжди перевіряємо товар перед відправкою та гарантуємо 100% якість</p>
					</div>
				</div>
			</div>
		</section>
		<section class="offer_section offer1">
			<section class="sect3 color_bg">
			<div class="title_block">
				<h1 class="main_title">Шланг для поливу XHOSE <br><span style="color:yellow;">З НАСАДКОЮ У ПОДАРУНОК! </span></h1>

			</div>
			</section>
					<div class="box">
				<img class="offer_image" src="images/offer.jpg" alt="">
			</div>
			<div class="price_block clearfix">
				<div class="price_item old">
					<div class="text">Звичайна ціна:</div>
					<div class="value">475 грн</div>
				</div>
				<div class="discount_block">
					<div class="text">знижка</div>
					<div class="value">-47%</div>
				</div>
				<div class="price_item new">
					<div class="text">Ціна сьогодні від:</div>
					<div class="value">249 грн</div>
				</div>
			</div>
			<div class="timer_block clearfix">
				<p>До кінця акції залишилося:</p>
				<div class="timer clearfix">
					<div class="timer_item">
						<div class="count hours"></div>
						<div class="text">годин</div>
					</div>
					<div class="timer_item">
						<div class="count minutes"></div>
						<div class="text">хвилин</div>
					</div>
					<div class="timer_item">
						<div class="count seconds"></div>
						<div class="text">секунд</div>
					</div>
				</div>
			</div>
			<div class="products_count">Залишилось <b>12</b> шлангів по акції</div><br>
			<div class="action_text">
				<h4>Надішліть заявку</h4>
				<p>і отримайте шланг для поливу XHOSEPRO <span>з вигодою в 47%</span></p>
			</div>

			<form action="zakaz.php" method="post" id="order_form" class="main-order-form order_form">



				 <p class="pp">Оберіть довжину (Метри):</p>
				  <div class="radio_form">
        
        <div class="flex">
            
            <input type="radio" id="contactChoice-v2-1" class="custom-checkbox checkbox price_field_s4" checked="" name="s4" value="15">
           
            <label for="contactChoice-v2-1" class="color_box color_box1" style="text-transform: none; font-size: 20px;">15 м.</label>
        </div>
        <div class="flex">
            <!-- <div class="color_box1"></div> -->

            <input type="radio" id="contactChoice-v2-2" class="custom-checkbox checkbox price_field_s4" name="s4" value="30">
           
            <label for="contactChoice-v2-2" class="color_box color_box1" style="text-transform: none; font-size: 20px;">30 м.</label>
        </div>
        <div class="flex">
            <!-- <div class="color_box1"></div> -->

            <input type="radio" id="contactChoice-v2-3" class="custom-checkbox checkbox price_field_s4" name="s4" value="45">
           
            <label for="contactChoice-v2-3" class="color_box color_box1" style="text-transform: none; font-size: 20px;">45 м.</label>
        </div>
        <div class="flex">
            <!-- <div class="color_box1"></div> -->

            <input type="radio" id="contactChoice-v2-4" class="custom-checkbox checkbox price_field_s4" name="s4" value="60">
           
            <label for="contactChoice-v2-4" class="color_box color_box1" style="text-transform: none; font-size: 20px;">60 м.</label>
        </div>
        <div class="flex">
            <!-- <div class="color_box1"></div> -->

            <input type="radio" id="contactChoice-v2-5" class="custom-checkbox checkbox price_field_s4" name="s4" value="75">
           
            <label for="contactChoice-v2-5" class="color_box color_box1" style="text-transform: none; font-size: 20px;">75 м.</label>
        </div>
        </div>
        <p class="pf">ДО сплати: <span id="price" style="color: #fffc00; font-size:30px">249 грн</span></p>
				<input class="field" type="text" name="name" placeholder="Введіть ім'я" required="">
				<input class="field" type="tel" name="phone" placeholder="Введіть телефон" required="" autocomplete="off" inputmode="tel">
				
				<input type="hidden" name="s2" class="price_field_s2" value="<?= $product_id ?>"/>
                <input type="hidden" name="s3" class="price_field_s3" value="<?= $product_name?>"/>
                <input type="hidden" name="s5" class="price_field_s5" value="<?= $fbq_code?>"/>
				
				<button type="submit" class="button">Замовити зі знижкою</button>
			

</form>
					</section>
		<footer class="footer_section">
			<div style="font-size:13px;text-align: center;">
              <p>
                                <br>
                Одеса, вул. М. Коцюбинського, 40              </p>
              <p style="text-align: center">

                Графік работи:
                Пн - Нд: 08:00 - 23:00 <br>                            
                <br>
                <a style="color:inherit;" href="policy.html">Політика конфіденційності</a>
                <br>
                <a style="color:inherit;" href="oferta.html">Публічна оферта</a>
                <br>
                <a style="color:inherit;" href="cookie.html">Файли cookie</a>
              </p>
            </div>
        </footer>
	</div>
	







    <script>
        
  
            document.getElementById("contactChoice-v2-1").onclick = function() {
            document.getElementById('price').innerHTML = 249 + " грн";
   

            };


            
            document.getElementById("contactChoice-v2-2").onclick = function() {
            document.getElementById('price').innerHTML = '399' +" грн";


            };


            
            document.getElementById("contactChoice-v2-3").onclick = function() {
            document.getElementById('price').innerHTML = 499 + " грн";           


            };  



                        document.getElementById("contactChoice-v2-4").onclick = function() {
            document.getElementById('price').innerHTML = 599 + " грн";          


            }; 


                        document.getElementById("contactChoice-v2-5").onclick = function() {
            document.getElementById('price').innerHTML = 699 + " грн";          


            }; 
    </script>





<script src="js/jquery.min.js"></script>
 <script src="js/jquery.inputmask.min.js"></script>
 
    <script>
    window.getCookie = function (name) {
            var match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
            if (match) return match[2];
        }
        $(document).ready(function () {
            $('[name="phone"]').inputmask({
                keepStatic: false,
                clearIncomplete: true,
                definitions: {
                    'z': {validator: '0'},
                    't': {validator: '3'}
                },
                mask: [
                    '+380 5z 999-99-99',
                    '+380 63 999-99-99',
                    '+380 66 999-99-99',
                    '+380 67 999-99-99',
                    '+380 68 999-99-99',
                    '+380 7t 999-99-99',
                    '+380 75 999-99-99',
                    '+380 77 999-99-99',
                    '+380 \\91 999-99-99',
                    '+380 \\93 999-99-99',
                    '+380 \\94 999-99-99',
                    '+380 \\95 999-99-99',
                    '+380 \\96 999-99-99',
                    '+380 \\97 999-99-99',
                    '+380 \\98 999-99-99',
                    '+380 \\9\\9 999-99-99'
                ]
            }).attr('required', true);
            // Assuming your form has an id "myForm"
            $('form').on('submit', function (e) {
                // Prevent the form from submitting
                e.preventDefault();

                // Check if the phone input is complete
                var phoneInput = $(this).find('[name="phone"]');
                if (phoneInput.inputmask("isComplete")) {
                    // If the phone input is complete, submit the form
                    $(this).children(".button").hide();
                    $('.img-loading', this).css('display', 'block');
                    this.submit();
                } else {
                    // If the phone input is incomplete, show an error message
                    alert("Введіть повний номер телефону.");
                }
            });
        });
    </script>



	<script src="js/previewYouTube.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/scripts.js"></script>
	<!-- /scripts -->






</body></html>